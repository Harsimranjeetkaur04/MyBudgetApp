package com.example.mybudget

data class Expense(
    val category: String,
    val amount: Int
)
